﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;

namespace Bartender_App.Controllers
{
    public class HomeController : Controller
    {
        List<Models.Item> orders;
        // GET: Home
        public ActionResult Index()
        {
            List<Bartender_App.Models.Item> items = GetItems();
            orders = new List<Models.Item>(); 
            Session["Items"] = items;
            return View(items);
        }

        private List<Bartender_App.Models.Item> GetItems()
        {
            List<Bartender_App.Models.Item> items = new List<Models.Item>();
            string path = "C:\\database/database.txt";
            try
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    string line = string.Empty;
                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] lineSplit = line.Trim().Split('|');
                        items.Add(
                            new Models.Item
                            {
                                ItemName = lineSplit[0],
                                Price = lineSplit[1],
                            }
                        );
                    }
                }
            }
            catch(DirectoryNotFoundException)
            {
                Directory.CreateDirectory("C:\\database");        
                using (StreamWriter sw = new StreamWriter(System.IO.File.Create(path)))
                {
                    List<Models.Item> defaultItems = new List<Models.Item>();
                    items.Add(
                        new Models.Item
                        {
                            ItemName = "Drink_1",
                            Price = "$5.00",
                        }
                    );
                    items.Add(
                        new Models.Item
                        {
                            ItemName = "Drink_2",
                            Price = "$6.00",
                        }
                    );
                    foreach(Models.Item item in items)
                    {
                        sw.WriteLine(item.ItemName + '|' + item.Price.ToString());
                    }
                }
                items.Clear();
                using (StreamReader sr = new StreamReader(path))
                {
                    string line = string.Empty;
                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] lineSplit = line.Trim().Split('|');
                        items.Add(
                            new Models.Item
                            {
                                ItemName = lineSplit[0],
                                Price = lineSplit[1],
                            }
                        );
                    }
                }
            }
            return items;
        }

        public ActionResult Order(string itemName)
        {
            List<Models.Item> items = (List<Models.Item>)Session["Items"];
            Models.Item item = items.Single(i => i.ItemName.Equals(itemName));
            orders.Add(item);
            if (item == null)
            {
                return HttpNotFound();
            }
            else
            {
                return View(item);
            }
        }

        private void WriteOrders()
        {
            if(!System.IO.File.Exists("C:\\database/orders.txt"))
            {
                System.IO.File.Create("C:\\database/orders.txt");
            }
            else
            {
                using (StreamWriter sw = new StreamWriter("C:\\database/orders.txt"))
                {
                    foreach(Models.Item item in orders)
                    {
                        sw.WriteLine(item.ItemName + "|" + item.Price);
                    }
                }
            }
        }
    }
}